export interface Student {
  student_id: string;
  name: string;
  class: string;
  comprehension: number; // 0-100
  attention: number; // 0-100
  focus: number; // 0-100
  retention: number; // 0-100
  assessment_score: number; // 0-100
  engagement_time: number; // minutes
  predicted_score?: number;
  confidence?: number;
  learning_persona?: LearningPersona;
}

export interface LearningPersona {
  id: string;
  name: string;
  description: string;
  characteristics: string[];
  color: string;
  students: number;
  averageScore: number;
}

export interface AnalyticsData {
  totalStudents: number;
  averageScore: number;
  averageAttention: number;
  averageFocus: number;
  averageComprehension: number;
  averageRetention: number;
  averageEngagement: number;
  topPerformers: Student[];
  strugglingStudents: Student[];
  correlations: CorrelationMatrix;
  insights: Insight[];
  personas: LearningPersona[];
}

export interface CorrelationMatrix {
  comprehension_score: number;
  attention_score: number;
  focus_score: number;
  retention_score: number;
  engagement_score: number;
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  type: 'positive' | 'warning' | 'info';
  impact: 'high' | 'medium' | 'low';
  value: number | string;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
  students?: number;
}