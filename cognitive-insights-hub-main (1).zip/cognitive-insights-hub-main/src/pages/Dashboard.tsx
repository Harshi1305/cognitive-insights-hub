import React, { useState } from 'react';
import { Brain, Users, Target, TrendingUp, Zap, BookOpen } from 'lucide-react';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { InsightCard } from '@/components/dashboard/InsightCard';
import { StudentTable } from '@/components/dashboard/StudentTable';
import { PersonasOverview } from '@/components/dashboard/PersonasOverview';
import { CorrelationHeatmap } from '@/components/charts/CorrelationHeatmap';
import { PerformanceScatter } from '@/components/charts/PerformanceScatter';
import { SkillsBarChart } from '@/components/charts/SkillsBarChart';
import { PersonaRadarChart } from '@/components/charts/PersonaRadarChart';
import { analyticsData, studentsData } from '@/data/syntheticData';
import { Student } from '@/types/student';

const Dashboard = () => {
  const [selectedStudents, setSelectedStudents] = useState<Student[]>([]);

  const handleStudentSelect = (student: Student, selected: boolean) => {
    if (selected) {
      setSelectedStudents(prev => [...prev, student]);
    } else {
      setSelectedStudents(prev => prev.filter(s => s.student_id !== student.student_id));
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-neural bg-clip-text text-transparent">
                NeuroFlow Analytics
              </h1>
              <p className="text-muted-foreground mt-1">
                Cognitive Skills & Student Performance Dashboard
              </p>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Brain className="h-5 w-5 text-primary" />
              <span>AI-Powered Learning Insights</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Total Students"
            value={analyticsData.totalStudents}
            icon={<Users className="h-5 w-5" />}
            subtitle="Active learners"
            trend={{ value: 12, label: "this month" }}
          />
          <MetricCard
            title="Average Score"
            value={`${analyticsData.averageScore}%`}
            icon={<Target className="h-5 w-5" />}
            subtitle="Assessment performance"
            trend={{ value: 8, label: "improvement" }}
          />
          <MetricCard
            title="Avg Attention"
            value={`${analyticsData.averageAttention}%`}
            icon={<Zap className="h-5 w-5" />}
            subtitle="Attention span"
            trend={{ value: 5, label: "this week" }}
          />
          <MetricCard
            title="Learning Personas"
            value={analyticsData.personas.length}
            icon={<BookOpen className="h-5 w-5" />}
            subtitle="AI-identified groups"
            trend={{ value: 15, label: "accuracy" }}
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SkillsBarChart data={analyticsData} />
          <CorrelationHeatmap data={analyticsData.correlations} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PerformanceScatter students={studentsData} />
          <PersonaRadarChart selectedStudents={selectedStudents} />
        </div>

        {/* Personas Overview */}
        <PersonasOverview personas={analyticsData.personas} />

        {/* Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {analyticsData.insights.map((insight) => (
            <InsightCard key={insight.id} insight={insight} />
          ))}
        </div>

        {/* Student Table */}
        <StudentTable
          students={studentsData}
          onStudentSelect={handleStudentSelect}
          selectedStudents={selectedStudents}
        />
      </div>
    </div>
  );
};

export default Dashboard;