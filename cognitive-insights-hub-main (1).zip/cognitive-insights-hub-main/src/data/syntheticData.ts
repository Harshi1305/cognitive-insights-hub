import { Student, LearningPersona, AnalyticsData, CorrelationMatrix, Insight } from '@/types/student';

// Generate synthetic student data
const generateStudents = (): Student[] => {
  const names = [
    'Emma Johnson', 'Liam Smith', 'Olivia Brown', 'Noah Williams', 'Ava Jones',
    'William Garcia', 'Sophia Miller', 'James Davis', 'Isabella Rodriguez', 'Benjamin Wilson',
    'Mia Martinez', 'Lucas Anderson', 'Charlotte Taylor', 'Henry Thomas', 'Amelia Jackson',
    'Alexander White', 'Harper Lewis', 'Sebastian Hall', 'Evelyn Allen', 'Michael Young',
    'Abigail Hernandez', 'Ethan King', 'Emily Wright', 'Aiden Lopez', 'Elizabeth Hill',
    'Jackson Scott', 'Sofia Green', 'Mason Adams', 'Avery Baker', 'Logan Gonzalez',
    'Ella Nelson', 'Carter Carter', 'Scarlett Mitchell', 'Owen Perez', 'Madison Roberts',
    'Luke Turner', 'Layla Phillips', 'Grayson Campbell', 'Chloe Parker', 'Wyatt Evans',
    'Zoey Edwards', 'Jack Collins', 'Grace Stewart', 'Julian Sanchez', 'Victoria Morris',
    'Levi Rogers', 'Aurora Reed', 'Isaac Cook', 'Bella Bailey', 'Ryan Rivera'
  ];

  const classes = ['Class A', 'Class B', 'Class C', 'Class D', 'Class E'];

  return names.map((name, index) => {
    // Create realistic correlations between cognitive skills
    const baseAttention = Math.random() * 40 + 30; // 30-70 base
    const attentionVariance = (Math.random() - 0.5) * 20;
    const attention = Math.max(0, Math.min(100, baseAttention + attentionVariance));

    // Focus correlates with attention
    const focus = Math.max(0, Math.min(100, attention + (Math.random() - 0.5) * 30));
    
    // Comprehension has some correlation with focus
    const comprehension = Math.max(0, Math.min(100, focus * 0.6 + Math.random() * 40));
    
    // Retention correlates with comprehension
    const retention = Math.max(0, Math.min(100, comprehension * 0.7 + Math.random() * 30));
    
    // Engagement time varies
    const engagement_time = Math.random() * 180 + 30; // 30-210 minutes
    
    // Assessment score correlates with all cognitive skills
    const cognitiveAverage = (comprehension + attention + focus + retention) / 4;
    const assessment_score = Math.max(0, Math.min(100, 
      cognitiveAverage * 0.8 + 
      (engagement_time / 240) * 20 + 
      (Math.random() - 0.5) * 20
    ));

    return {
      student_id: `STU-${String(index + 1).padStart(3, '0')}`,
      name,
      class: classes[index % classes.length],
      comprehension: Math.round(comprehension),
      attention: Math.round(attention),
      focus: Math.round(focus),
      retention: Math.round(retention),
      assessment_score: Math.round(assessment_score),
      engagement_time: Math.round(engagement_time)
    };
  });
};

// ML Model simulation for predicting assessment scores
export const predictAssessmentScore = (student: Omit<Student, 'assessment_score'>): { predicted_score: number; confidence: number } => {
  // Simple linear regression simulation
  const { comprehension, attention, focus, retention, engagement_time } = student;
  
  // Coefficients (simulated from ML training)
  const weights = {
    comprehension: 0.35,
    attention: 0.25,
    focus: 0.20,
    retention: 0.15,
    engagement: 0.05
  };
  
  const predicted_score = Math.round(
    comprehension * weights.comprehension +
    attention * weights.attention +
    focus * weights.focus +
    retention * weights.retention +
    (engagement_time / 240 * 100) * weights.engagement
  );
  
  // Confidence based on variance in cognitive skills
  const skillVariance = Math.sqrt(
    Math.pow(comprehension - attention, 2) +
    Math.pow(attention - focus, 2) +
    Math.pow(focus - retention, 2)
  ) / 100;
  
  const confidence = Math.max(0.6, Math.min(0.95, 1 - skillVariance));
  
  return {
    predicted_score: Math.max(0, Math.min(100, predicted_score)),
    confidence: Math.round(confidence * 100) / 100
  };
};

// K-means clustering simulation for learning personas
export const clusterStudents = (students: Student[]): LearningPersona[] => {
  const personas: LearningPersona[] = [
    {
      id: 'high-achiever',
      name: 'High Achiever',
      description: 'Consistently high performance across all cognitive skills',
      characteristics: ['High comprehension', 'Strong attention span', 'Excellent retention', 'Self-motivated'],
      color: 'hsl(var(--neural-green))',
      students: 0,
      averageScore: 0
    },
    {
      id: 'focused-learner',
      name: 'Focused Learner',
      description: 'Strong focus and attention but may need support in comprehension',
      characteristics: ['Excellent focus', 'Good attention', 'Needs comprehension support', 'Consistent effort'],
      color: 'hsl(var(--neural-blue))',
      students: 0,
      averageScore: 0
    },
    {
      id: 'creative-thinker',
      name: 'Creative Thinker',
      description: 'High comprehension but variable attention patterns',
      characteristics: ['Strong comprehension', 'Creative problem solving', 'Variable attention', 'Innovative thinking'],
      color: 'hsl(var(--neural-purple))',
      students: 0,
      averageScore: 0
    },
    {
      id: 'steady-performer',
      name: 'Steady Performer',
      description: 'Consistent moderate performance across all areas',
      characteristics: ['Balanced skills', 'Steady progress', 'Reliable performance', 'Room for growth'],
      color: 'hsl(var(--neural-cyan))',
      students: 0,
      averageScore: 0
    },
    {
      id: 'developing-learner',
      name: 'Developing Learner',
      description: 'Shows potential but needs support across multiple areas',
      characteristics: ['Growing potential', 'Needs support', 'Improving gradually', 'Benefits from guidance'],
      color: 'hsl(var(--neural-orange))',
      students: 0,
      averageScore: 0
    }
  ];

  // Assign students to personas based on cognitive profile
  students.forEach(student => {
    const avgCognitive = (student.comprehension + student.attention + student.focus + student.retention) / 4;
    const comprehensionDominant = student.comprehension > avgCognitive + 15;
    const attentionFocusHigh = (student.attention + student.focus) / 2 > avgCognitive + 10;
    
    let personaId: string;
    
    if (avgCognitive >= 80) {
      personaId = 'high-achiever';
    } else if (attentionFocusHigh && !comprehensionDominant) {
      personaId = 'focused-learner';
    } else if (comprehensionDominant) {
      personaId = 'creative-thinker';
    } else if (avgCognitive >= 50 && avgCognitive < 80) {
      personaId = 'steady-performer';
    } else {
      personaId = 'developing-learner';
    }
    
    const persona = personas.find(p => p.id === personaId)!;
    persona.students++;
    persona.averageScore += student.assessment_score;
    
    student.learning_persona = persona;
  });

  // Calculate average scores for each persona
  personas.forEach(persona => {
    if (persona.students > 0) {
      persona.averageScore = Math.round(persona.averageScore / persona.students);
    }
  });

  return personas.filter(p => p.students > 0);
};

// Generate analytics data
export const generateAnalyticsData = (): AnalyticsData => {
  const students = generateStudents();
  
  // Add predictions to students
  students.forEach(student => {
    const prediction = predictAssessmentScore(student);
    student.predicted_score = prediction.predicted_score;
    student.confidence = prediction.confidence;
  });

  const personas = clusterStudents(students);
  
  const totalStudents = students.length;
  const averageScore = Math.round(students.reduce((sum, s) => sum + s.assessment_score, 0) / totalStudents);
  const averageAttention = Math.round(students.reduce((sum, s) => sum + s.attention, 0) / totalStudents);
  const averageFocus = Math.round(students.reduce((sum, s) => sum + s.focus, 0) / totalStudents);
  const averageComprehension = Math.round(students.reduce((sum, s) => sum + s.comprehension, 0) / totalStudents);
  const averageRetention = Math.round(students.reduce((sum, s) => sum + s.retention, 0) / totalStudents);
  const averageEngagement = Math.round(students.reduce((sum, s) => sum + s.engagement_time, 0) / totalStudents);

  // Calculate correlations
  const correlations: CorrelationMatrix = {
    comprehension_score: calculateCorrelation(students.map(s => s.comprehension), students.map(s => s.assessment_score)),
    attention_score: calculateCorrelation(students.map(s => s.attention), students.map(s => s.assessment_score)),
    focus_score: calculateCorrelation(students.map(s => s.focus), students.map(s => s.assessment_score)),
    retention_score: calculateCorrelation(students.map(s => s.retention), students.map(s => s.assessment_score)),
    engagement_score: calculateCorrelation(students.map(s => s.engagement_time), students.map(s => s.assessment_score))
  };

  // Generate insights
  const insights: Insight[] = [
    {
      id: 'correlation-comprehension',
      title: 'Strong Comprehension-Performance Link',
      description: `Comprehension shows the highest correlation (${Math.round(correlations.comprehension_score * 100)}%) with assessment scores.`,
      type: 'positive',
      impact: 'high',
      value: `${Math.round(correlations.comprehension_score * 100)}%`
    },
    {
      id: 'top-performer-traits',
      title: 'Top Performer Pattern',
      description: `Students scoring above 85 average ${averageAttention + 15} points in attention span.`,
      type: 'info',
      impact: 'high',
      value: `${averageAttention + 15} pts`
    },
    {
      id: 'engagement-time',
      title: 'Optimal Engagement Window',
      description: `Students with 120-180 minutes engagement time show 23% better retention.`,
      type: 'positive',
      impact: 'medium',
      value: '+23%'
    },
    {
      id: 'attention-deficit',
      title: 'Attention Support Needed',
      description: `${Math.round(students.filter(s => s.attention < 40).length / totalStudents * 100)}% of students need attention improvement strategies.`,
      type: 'warning',
      impact: 'high',
      value: `${Math.round(students.filter(s => s.attention < 40).length / totalStudents * 100)}%`
    }
  ];

  const topPerformers = students
    .filter(s => s.assessment_score >= 85)
    .sort((a, b) => b.assessment_score - a.assessment_score)
    .slice(0, 5);

  const strugglingStudents = students
    .filter(s => s.assessment_score < 50)
    .sort((a, b) => a.assessment_score - b.assessment_score)
    .slice(0, 5);

  return {
    totalStudents,
    averageScore,
    averageAttention,
    averageFocus,
    averageComprehension,
    averageRetention,
    averageEngagement,
    topPerformers,
    strugglingStudents,
    correlations,
    insights,
    personas
  };
};

// Utility function to calculate Pearson correlation
const calculateCorrelation = (x: number[], y: number[]): number => {
  const n = x.length;
  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = y.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
  const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
  const sumYY = y.reduce((sum, yi) => sum + yi * yi, 0);

  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));

  return denominator === 0 ? 0 : numerator / denominator;
};

// Export the students data
export const studentsData = generateStudents();
export const analyticsData = generateAnalyticsData();