import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LearningPersona } from '@/types/student';
import { Users, Target, TrendingUp } from 'lucide-react';

interface PersonasOverviewProps {
  personas: LearningPersona[];
}

export const PersonasOverview = ({ personas }: PersonasOverviewProps) => {
  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
          Learning Personas Distribution
        </CardTitle>
        <CardDescription>
          AI-clustered student groups based on cognitive patterns
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {personas.map((persona) => (
            <div 
              key={persona.id} 
              className="group p-4 rounded-lg border border-border/30 bg-background/20 hover:bg-background/40 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-4 h-4 rounded-full animate-pulse-neural"
                    style={{ backgroundColor: persona.color }}
                  />
                  <div>
                    <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {persona.name}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {persona.description}
                    </p>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">
                      {persona.students} students
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-bold text-primary">
                      {persona.averageScore}% avg
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-3">
                {persona.characteristics.map((characteristic, index) => (
                  <Badge 
                    key={index} 
                    variant="outline" 
                    className="text-xs bg-background/50"
                    style={{ borderColor: persona.color + '40', color: persona.color }}
                  >
                    {characteristic}
                  </Badge>
                ))}
              </div>
              
              {/* Progress Bar */}
              <div className="relative h-2 bg-muted/20 rounded-full overflow-hidden">
                <div 
                  className="h-full transition-all duration-1000 ease-out rounded-full"
                  style={{ 
                    width: `${(persona.students / personas.reduce((sum, p) => sum + p.students, 0)) * 100}%`,
                    backgroundColor: persona.color 
                  }}
                />
              </div>
              <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                <span>{((persona.students / personas.reduce((sum, p) => sum + p.students, 0)) * 100).toFixed(1)}% of total students</span>
                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-3 w-3" />
                  <span>Performance: {persona.averageScore > 70 ? 'Strong' : persona.averageScore > 50 ? 'Moderate' : 'Needs Support'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Summary Stats */}
        <div className="mt-6 pt-4 border-t border-border/50">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-sm font-medium text-foreground">Total Personas</div>
              <div className="text-lg font-bold text-primary">{personas.length}</div>
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">Best Performing</div>
              <div className="text-sm font-bold text-neural-green">
                {personas.reduce((max, p) => p.averageScore > max.averageScore ? p : max, personas[0])?.name}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">Largest Group</div>
              <div className="text-sm font-bold text-neural-blue">
                {personas.reduce((max, p) => p.students > max.students ? p : max, personas[0])?.name}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};