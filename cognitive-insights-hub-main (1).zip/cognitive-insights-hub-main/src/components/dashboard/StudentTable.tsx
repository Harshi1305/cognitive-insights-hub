import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Search, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  Brain,
  Target,
  TrendingUp
} from 'lucide-react';
import { Student } from '@/types/student';
import { cn } from '@/lib/utils';

interface StudentTableProps {
  students: Student[];
  onStudentSelect: (student: Student, selected: boolean) => void;
  selectedStudents: Student[];
}

type SortField = keyof Student;
type SortDirection = 'asc' | 'desc';

export const StudentTable = ({ students, onStudentSelect, selectedStudents }: StudentTableProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('assessment_score');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  // Filter and sort students
  const filteredAndSortedStudents = useMemo(() => {
    let filtered = students.filter(student =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.class.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.learning_persona?.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    filtered.sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortDirection === 'asc' 
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }
      
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
      }
      
      return 0;
    });

    return filtered;
  }, [students, searchTerm, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4" />;
    return sortDirection === 'asc' 
      ? <ArrowUp className="h-4 w-4" /> 
      : <ArrowDown className="h-4 w-4" />;
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-neural-green';
    if (score >= 70) return 'text-neural-blue';
    if (score >= 50) return 'text-neural-cyan';
    return 'text-neural-orange';
  };

  const getPersonaBadgeColor = (persona?: string) => {
    switch (persona) {
      case 'High Achiever': return 'bg-neural-green/20 text-neural-green border-neural-green/30';
      case 'Focused Learner': return 'bg-neural-blue/20 text-neural-blue border-neural-blue/30';
      case 'Creative Thinker': return 'bg-neural-purple/20 text-neural-purple border-neural-purple/30';
      case 'Steady Performer': return 'bg-neural-cyan/20 text-neural-cyan border-neural-cyan/30';
      case 'Developing Learner': return 'bg-neural-orange/20 text-neural-orange border-neural-orange/30';
      default: return 'bg-muted/20 text-muted-foreground border-muted/30';
    }
  };

  const isSelected = (student: Student) => 
    selectedStudents.some(s => s.student_id === student.student_id);

  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
              Student Performance Database
            </CardTitle>
            <CardDescription>
              Comprehensive view of all student cognitive and performance data
            </CardDescription>
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Brain className="h-4 w-4" />
            <span>{filteredAndSortedStudents.length} students</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Search and Filters */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search students by name, class, or learning persona..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-background/50"
            />
          </div>
          <Badge variant="outline" className="text-primary">
            {selectedStudents.length} selected for comparison
          </Badge>
        </div>

        {/* Table */}
        <div className="rounded-lg border border-border/50 bg-background/30 backdrop-blur-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 bg-muted/10">
                <TableHead className="w-12">
                  <div className="flex items-center justify-center">
                    <Target className="h-4 w-4 text-primary" />
                  </div>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('name')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Student {getSortIcon('name')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('class')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Class {getSortIcon('class')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('comprehension')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Comprehension {getSortIcon('comprehension')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('attention')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Attention {getSortIcon('attention')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('focus')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Focus {getSortIcon('focus')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('retention')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Retention {getSortIcon('retention')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('assessment_score')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Score {getSortIcon('assessment_score')}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('predicted_score')}
                    className="font-semibold text-foreground hover:text-primary"
                  >
                    Predicted {getSortIcon('predicted_score')}
                  </Button>
                </TableHead>
                <TableHead>Learning Persona</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAndSortedStudents.map((student) => (
                <TableRow 
                  key={student.student_id} 
                  className={cn(
                    "border-border/30 hover:bg-muted/20 transition-colors",
                    isSelected(student) && "bg-primary/5 border-primary/20"
                  )}
                >
                  <TableCell>
                    <Checkbox
                      checked={isSelected(student)}
                      onCheckedChange={(checked) => onStudentSelect(student, !!checked)}
                      className="border-border"
                    />
                  </TableCell>
                  <TableCell className="font-medium">
                    <div>
                      <div className="text-foreground">{student.name}</div>
                      <div className="text-xs text-muted-foreground">{student.student_id}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">
                      {student.class}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={getScoreColor(student.comprehension)}>
                      {student.comprehension}%
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={getScoreColor(student.attention)}>
                      {student.attention}%
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={getScoreColor(student.focus)}>
                      {student.focus}%
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className={getScoreColor(student.retention)}>
                      {student.retention}%
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <span className={cn("font-bold", getScoreColor(student.assessment_score))}>
                        {student.assessment_score}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <span className={cn("text-sm", getScoreColor(student.predicted_score || 0))}>
                        {student.predicted_score}%
                      </span>
                      <TrendingUp className="h-3 w-3 text-muted-foreground" />
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {Math.round((student.confidence || 0) * 100)}% confidence
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={cn("text-xs", getPersonaBadgeColor(student.learning_persona?.name))}
                    >
                      {student.learning_persona?.name || 'Unassigned'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Summary Stats */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-border/50">
          <div className="text-center">
            <div className="text-sm font-medium text-foreground">Average Score</div>
            <div className="text-lg font-bold text-primary">
              {Math.round(filteredAndSortedStudents.reduce((sum, s) => sum + s.assessment_score, 0) / filteredAndSortedStudents.length)}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-foreground">Top Performer</div>
            <div className="text-lg font-bold text-neural-green">
              {Math.max(...filteredAndSortedStudents.map(s => s.assessment_score))}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-foreground">Needs Support</div>
            <div className="text-lg font-bold text-neural-orange">
              {filteredAndSortedStudents.filter(s => s.assessment_score < 50).length}
            </div>
          </div>
          <div className="text-center">
            <div className="text-sm font-medium text-foreground">Selected</div>
            <div className="text-lg font-bold text-primary">
              {selectedStudents.length}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};