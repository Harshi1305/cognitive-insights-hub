import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Insight } from '@/types/student';

interface InsightCardProps {
  insight: Insight;
  className?: string;
}

export const InsightCard = ({ insight, className }: InsightCardProps) => {
  const getIcon = () => {
    switch (insight.type) {
      case 'positive':
        return <CheckCircle className="h-5 w-5 text-neural-green" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-neural-orange" />;
      case 'info':
        return <Info className="h-5 w-5 text-neural-blue" />;
      default:
        return <Info className="h-5 w-5" />;
    }
  };

  const getBorderColor = () => {
    switch (insight.type) {
      case 'positive':
        return 'border-neural-green/20';
      case 'warning':
        return 'border-neural-orange/20';
      case 'info':
        return 'border-neural-blue/20';
      default:
        return 'border-border';
    }
  };

  const getBackgroundGradient = () => {
    switch (insight.type) {
      case 'positive':
        return 'bg-gradient-to-br from-neural-green/5 to-neural-green/10';
      case 'warning':
        return 'bg-gradient-to-br from-neural-orange/5 to-neural-orange/10';
      case 'info':
        return 'bg-gradient-to-br from-neural-blue/5 to-neural-blue/10';
      default:
        return 'bg-gradient-card';
    }
  };

  return (
    <Card className={cn(
      "p-4 border backdrop-blur-sm transition-all duration-300",
      "hover:scale-105 hover:shadow-lg animate-slide-in",
      getBorderColor(),
      getBackgroundGradient(),
      className
    )}>
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          {getIcon()}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-foreground">
              {insight.title}
            </h4>
            <div className="flex items-center space-x-2">
              <Badge 
                variant="outline" 
                className={cn(
                  "text-xs",
                  insight.impact === 'high' && "border-neural-purple text-neural-purple",
                  insight.impact === 'medium' && "border-neural-blue text-neural-blue",
                  insight.impact === 'low' && "border-muted-foreground text-muted-foreground"
                )}
              >
                {insight.impact} impact
              </Badge>
              <div className="text-lg font-bold text-primary">
                {insight.value}
              </div>
            </div>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {insight.description}
          </p>
        </div>
      </div>
    </Card>
  );
};