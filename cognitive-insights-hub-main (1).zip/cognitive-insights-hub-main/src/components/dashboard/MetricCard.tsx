import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: {
    value: number;
    label: string;
  };
  className?: string;
  animated?: boolean;
}

export const MetricCard = ({ 
  title, 
  value, 
  subtitle, 
  icon, 
  trend, 
  className,
  animated = true 
}: MetricCardProps) => {
  return (
    <Card className={cn(
      "p-6 bg-gradient-card border-border/50 backdrop-blur-sm",
      animated && "animate-pulse-neural hover:animate-glow transition-all duration-300",
      "hover:border-primary/30 hover:shadow-neural",
      className
    )}>
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <div className="flex items-baseline space-x-2">
            <h3 className="text-2xl font-bold tracking-tight bg-gradient-neural bg-clip-text text-transparent">
              {value}
            </h3>
            {trend && (
              <span className={cn(
                "text-xs font-medium px-2 py-1 rounded-full",
                trend.value > 0 
                  ? "text-neural-green bg-neural-green/10" 
                  : "text-neural-orange bg-neural-orange/10"
              )}>
                {trend.value > 0 ? '+' : ''}{trend.value}% {trend.label}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
        {icon && (
          <div className="p-2 rounded-lg bg-primary/10 text-primary animate-float">
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
};