import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Student } from '@/types/student';

interface PerformanceScatterProps {
  students: Student[];
}

export const PerformanceScatter = ({ students }: PerformanceScatterProps) => {
  // Group students by learning persona for different colors
  const personaData = students.reduce((acc, student) => {
    const persona = student.learning_persona?.name || 'Unassigned';
    if (!acc[persona]) {
      acc[persona] = [];
    }
    acc[persona].push({
      x: student.attention,
      y: student.assessment_score,
      name: student.name,
      persona,
      color: student.learning_persona?.color || '#8884d8'
    });
    return acc;
  }, {} as Record<string, any[]>);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-card/95 backdrop-blur-sm border border-border/50 rounded-lg p-3 shadow-lg">
          <p className="font-medium text-foreground">{data.name}</p>
          <p className="text-sm text-muted-foreground">Persona: {data.persona}</p>
          <p className="text-sm text-neural-blue">Attention: {data.x}%</p>
          <p className="text-sm text-neural-green">Assessment: {data.y}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
          Attention vs Performance Analysis
        </CardTitle>
        <CardDescription>
          Student distribution by attention span and assessment scores
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              type="number" 
              dataKey="x" 
              domain={[0, 100]}
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
              tickLine={{ stroke: 'hsl(var(--border))' }}
            />
            <YAxis 
              type="number" 
              dataKey="y" 
              domain={[0, 100]}
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
              tickLine={{ stroke: 'hsl(var(--border))' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            {Object.entries(personaData).map(([persona, data], index) => (
              <Scatter
                key={persona}
                name={persona}
                data={data}
                fill={data[0]?.color || `hsl(${index * 60}, 70%, 60%)`}
                opacity={0.8}
              />
            ))}
          </ScatterChart>
        </ResponsiveContainer>
        
        {/* Performance Quadrants */}
        <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
          <div className="space-y-1">
            <div className="font-medium text-neural-green">High Attention + High Performance</div>
            <div className="text-muted-foreground">
              {students.filter(s => s.attention >= 70 && s.assessment_score >= 70).length} students
            </div>
          </div>
          <div className="space-y-1">
            <div className="font-medium text-neural-blue">High Attention + Low Performance</div>
            <div className="text-muted-foreground">
              {students.filter(s => s.attention >= 70 && s.assessment_score < 70).length} students
            </div>
          </div>
          <div className="space-y-1">
            <div className="font-medium text-neural-orange">Low Attention + High Performance</div>
            <div className="text-muted-foreground">
              {students.filter(s => s.attention < 70 && s.assessment_score >= 70).length} students
            </div>
          </div>
          <div className="space-y-1">
            <div className="font-medium text-neural-pink">Low Attention + Low Performance</div>
            <div className="text-muted-foreground">
              {students.filter(s => s.attention < 70 && s.assessment_score < 70).length} students
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};