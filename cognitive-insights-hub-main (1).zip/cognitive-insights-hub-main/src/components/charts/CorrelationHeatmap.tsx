import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CorrelationMatrix } from '@/types/student';

interface CorrelationHeatmapProps {
  data: CorrelationMatrix;
}

export const CorrelationHeatmap = ({ data }: CorrelationHeatmapProps) => {
  const correlations = [
    { skill: 'Comprehension', value: data.comprehension_score, key: 'comprehension_score' },
    { skill: 'Attention', value: data.attention_score, key: 'attention_score' },
    { skill: 'Focus', value: data.focus_score, key: 'focus_score' },
    { skill: 'Retention', value: data.retention_score, key: 'retention_score' },
    { skill: 'Engagement', value: data.engagement_score, key: 'engagement_score' }
  ];

  const getCorrelationColor = (value: number) => {
    const intensity = Math.abs(value);
    if (intensity >= 0.8) return value > 0 ? 'bg-neural-green' : 'bg-neural-orange';
    if (intensity >= 0.6) return value > 0 ? 'bg-neural-blue' : 'bg-neural-pink';
    if (intensity >= 0.4) return value > 0 ? 'bg-neural-cyan' : 'bg-neural-purple';
    return 'bg-muted';
  };

  const getCorrelationStrength = (value: number) => {
    const intensity = Math.abs(value);
    if (intensity >= 0.8) return 'Very Strong';
    if (intensity >= 0.6) return 'Strong';
    if (intensity >= 0.4) return 'Moderate';
    if (intensity >= 0.2) return 'Weak';
    return 'Very Weak';
  };

  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
          Skill-Performance Correlations
        </CardTitle>
        <CardDescription>
          How cognitive skills correlate with assessment scores
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {correlations.map(({ skill, value, key }) => (
            <div key={key} className="group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">{skill}</span>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-muted-foreground">
                    {getCorrelationStrength(value)}
                  </span>
                  <span className="text-sm font-bold text-primary">
                    {(value * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
              <div className="relative h-8 bg-muted/20 rounded-lg overflow-hidden">
                <div 
                  className={`h-full transition-all duration-1000 ease-out ${getCorrelationColor(value)} opacity-80`}
                  style={{ width: `${Math.abs(value) * 100}%` }}
                />
                <div className="absolute inset-0 flex items-center px-3">
                  <div className="text-xs font-medium text-foreground/80">
                    r = {value.toFixed(3)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-4 border-t border-border/50">
          <div className="flex items-center justify-center space-x-6 text-xs text-muted-foreground">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-neural-green"></div>
              <span>Strong Positive</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-neural-blue"></div>
              <span>Moderate Positive</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-muted"></div>
              <span>Weak</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};