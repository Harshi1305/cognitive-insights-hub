import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';
import { Student } from '@/types/student';

interface PersonaRadarChartProps {
  selectedStudents: Student[];
}

export const PersonaRadarChart = ({ selectedStudents }: PersonaRadarChartProps) => {
  if (selectedStudents.length === 0) {
    return (
      <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
            Student Cognitive Profile
          </CardTitle>
          <CardDescription>
            Select students to compare their cognitive skills
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[400px]">
          <div className="text-center text-muted-foreground">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted/20 flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
            <p>Select students from the table below to view their cognitive profiles</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Prepare radar chart data
  const skills = ['Comprehension', 'Attention', 'Focus', 'Retention'];
  
  const radarData = skills.map(skill => {
    const dataPoint: any = { skill };
    
    selectedStudents.forEach((student, index) => {
      const skillKey = skill.toLowerCase() as keyof Pick<Student, 'comprehension' | 'attention' | 'focus' | 'retention'>;
      dataPoint[`student${index}`] = student[skillKey];
      dataPoint[`studentName${index}`] = student.name;
      dataPoint[`studentColor${index}`] = student.learning_persona?.color || `hsl(${index * 120}, 70%, 60%)`;
    });
    
    return dataPoint;
  });

  const colors = ['hsl(var(--neural-purple))', 'hsl(var(--neural-blue))', 'hsl(var(--neural-cyan))', 'hsl(var(--neural-green))', 'hsl(var(--neural-orange))'];

  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
          Student Cognitive Profile Comparison
        </CardTitle>
        <CardDescription>
          Radar chart comparing cognitive skills across selected students
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart data={radarData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <PolarGrid 
              stroke="hsl(var(--border))" 
              opacity={0.3}
            />
            <PolarAngleAxis 
              dataKey="skill" 
              tick={{ fontSize: 12, fill: 'hsl(var(--foreground))' }}
            />
            <PolarRadiusAxis 
              domain={[0, 100]} 
              tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              angle={90}
            />
            
            {selectedStudents.map((student, index) => (
              <Radar
                key={student.student_id}
                name={student.name}
                dataKey={`student${index}`}
                stroke={colors[index % colors.length]}
                fill={colors[index % colors.length]}
                fillOpacity={0.1}
                strokeWidth={2}
              />
            ))}
            
            <Legend />
          </RadarChart>
        </ResponsiveContainer>
        
        {/* Student Summary */}
        <div className="mt-6 space-y-3">
          {selectedStudents.map((student, index) => (
            <div key={student.student_id} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
              <div className="flex items-center space-x-3">
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: colors[index % colors.length] }}
                />
                <div>
                  <div className="font-medium text-foreground">{student.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {student.learning_persona?.name} • Class {student.class}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium text-primary">
                  Score: {student.assessment_score}%
                </div>
                <div className="text-xs text-muted-foreground">
                  Avg Cognitive: {Math.round((student.comprehension + student.attention + student.focus + student.retention) / 4)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};