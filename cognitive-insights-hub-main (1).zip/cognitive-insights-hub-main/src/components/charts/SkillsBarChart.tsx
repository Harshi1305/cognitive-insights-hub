import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { AnalyticsData } from '@/types/student';

interface SkillsBarChartProps {
  data: AnalyticsData;
}

export const SkillsBarChart = ({ data }: SkillsBarChartProps) => {
  const chartData = [
    {
      skill: 'Comprehension',
      average: data.averageComprehension,
      correlation: Math.round(data.correlations.comprehension_score * 100),
      color: 'hsl(var(--neural-purple))'
    },
    {
      skill: 'Attention',
      average: data.averageAttention,
      correlation: Math.round(data.correlations.attention_score * 100),
      color: 'hsl(var(--neural-blue))'
    },
    {
      skill: 'Focus',
      average: data.averageFocus,
      correlation: Math.round(data.correlations.focus_score * 100),
      color: 'hsl(var(--neural-cyan))'
    },
    {
      skill: 'Retention',
      average: data.averageRetention,
      correlation: Math.round(data.correlations.retention_score * 100),
      color: 'hsl(var(--neural-green))'
    }
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card/95 backdrop-blur-sm border border-border/50 rounded-lg p-3 shadow-lg">
          <p className="font-medium text-foreground mb-1">{label}</p>
          <p className="text-sm text-neural-blue">
            Average Score: {payload[0]?.value}%
          </p>
          <p className="text-sm text-neural-green">
            Performance Correlation: {payload[1]?.value}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="bg-gradient-card border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="bg-gradient-neural bg-clip-text text-transparent">
          Cognitive Skills Overview
        </CardTitle>
        <CardDescription>
          Average scores and performance correlations by skill
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              dataKey="skill" 
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
              tickLine={{ stroke: 'hsl(var(--border))' }}
            />
            <YAxis 
              tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              axisLine={{ stroke: 'hsl(var(--border))' }}
              tickLine={{ stroke: 'hsl(var(--border))' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              dataKey="average" 
              name="Average Score"
              fill="hsl(var(--primary))"
              radius={[4, 4, 0, 0]}
              opacity={0.8}
            />
            <Bar 
              dataKey="correlation" 
              name="Performance Correlation"
              fill="hsl(var(--accent))"
              radius={[4, 4, 0, 0]}
              opacity={0.7}
            />
          </BarChart>
        </ResponsiveContainer>
        
        {/* Skill Insights */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          {chartData.map((skill) => (
            <div key={skill.skill} className="text-center space-y-1">
              <div className="text-sm font-medium text-foreground">{skill.skill}</div>
              <div className="text-xs text-muted-foreground">
                Avg: {skill.average}% | Corr: {skill.correlation}%
              </div>
              <div 
                className="h-1 rounded-full mx-auto"
                style={{ 
                  width: `${skill.correlation}%`,
                  backgroundColor: skill.color,
                  minWidth: '20px'
                }}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};